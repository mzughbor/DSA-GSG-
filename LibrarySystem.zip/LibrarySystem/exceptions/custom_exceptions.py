class ItemNotAvailableError(Exception):
    pass

class UserNotFoundError(Exception):
    pass

class ItemNotFoundError(Exception):
    pass