# Library Management System\nRun `main.py` to use the system. 
# you have to cd the dir for the project first. then run the main.py file.
